﻿using System;
using System.IO;
using System.Collections.Generic;
// Names:

namespace IntroCS
{
	/// A class that maintains a list of items. 
	public class Inventory
	{
		private List<Item> InventoryList;

		/// Create an empty list of items. 
		public Inventory()
		{
			InventoryList = new List<Item>();
		}
		//Additem chunk
		// Add item to the list.
		public bool Additem(Item item)
		{   
			InventoryList.Add (item);
			return true; 
		}
		public bool CheckInventory(string title){//Used to see if the user has the item in their inventory.
			foreach (Item i in InventoryList) {
				if (i.GetTitle () == title) {
					return true;
				}
			}
			return false;
		}

		public void PrintInventory() //Print's inventory. 
		{  
			InventoryList.ForEach(Console.WriteLine);
		}

		public void ExamineItem(string title){ //Function that allows the user to examine an item.
			foreach (Item i in InventoryList) {
				if (i.GetTitle () == title) {
					Console.WriteLine (i.GetDescription ());
				}
			}
		}
		//Special function that removes an object from the list.
		//Used twice. 
		//Both times to replace a item (gun or hammer)
		//And to make it a (magic gun) or (magic hammer)
		public void AddMagic(string title){ 
			for (int j = 0; j < InventoryList.Count; j++) {
				if (InventoryList [j].GetTitle () == title) {
					InventoryList.RemoveAt (j);
					break;
				}
			}
		}
	}
}
