﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroCS
{
	public class Room1
	{
		public static void Test()
		{
			Iri ();
		}
		public static void Iri () //Function for Iri's Room. Very rough draft of story at the moment.
								  //However, most of the functions are accomplished at this point throughtout 
								 //everywhere.
		{
			Inventory items = new Inventory (); //What the user has in his inventory that he can use
			Inventory objects = new Inventory (); //Items in the room that can be examined
			int counter = 1;
			string prompt = "";
			ForReader (0, 5);
			for (int i = 0; i < counter; i++) {
				prompt = UI.PromptLine (">> ");
				Console.WriteLine ();
				counter++;
				if (prompt == "read note") {
					ForReader (12, 14);
				} else if (prompt == "Look around") {
					ForReader (14, 32);
				} else if (prompt == "help") {
					ForReader (5, 12);
				} else if (prompt == "examine hammer") {
					if (objects.CheckInventory ("Hammer") == false) {
						objects.Additem (new Item ("Hammer", "It appears to have blood on it, and be durable. Might be useful."));
					}
					objects.ExamineItem ("Hammer");
				} else if (prompt == "pickup hammer") {
					items.Additem (new Item ("Hammer", "It appears to have blood, and be durable. Might be useful."));
					ForReader (34, 36);
				} else if (items.CheckInventory ("Hammer") && (prompt == "Use hammer on wall")) {
					ForReader (36, 38);
				}
				else if (items.CheckInventory("Hammer") && (prompt == "Use hammer on poster")){
					items.AddMagic("Hammer");
					items.Additem(new Item("Magic Hammer", "The hammer is infused with a special kind of magic that has the glowing word 'break;' written all over it. You feel the power surge through you, feeling like you can break anything."));
					items.ExamineItem("Magic Hammer");
				}
				else
					ForReader (32, 34);
			}
		}
		public static void ForReader(int adder, int number){
			StreamReader first_reader = new StreamReader ("reader_room1.txt");
			var everything = first_reader.ReadToEnd ();
			first_reader.Close ();
			string [] everyline = everything.Split('\n');
			while (adder < number){
				Console.WriteLine (everyline [adder]);
				adder++;
			}
		}
	}	
}


