﻿//using System;

//namespace IntroCS
//{
	//public interface EscapeGameInterface
	//{
	//	void Play ();
	//}
//}

