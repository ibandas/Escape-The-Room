﻿using System;
using System.IO;
using System.Collections.Generic;

namespace IntroCS
{
	public class PlayEscapeGame
	{
		public static void Main (string [] args)
		{
			StreamReader reader = new StreamReader ("game_introduction.txt");
			var allLines = reader.ReadToEnd ();
			reader.Close ();
			string [] lines = allLines.Split('\n');
			foreach (string line in lines){
				Console.WriteLine (line);
			}

			Console.WriteLine ("You will begin this game in Room 1, good luck");
			Room1.Test();



		}
	}
}




