﻿using System;

namespace COMP170001_Team4
{
	public class EmptyClass
	{
		public EmptyClass ()
		{
		}
	}
}

