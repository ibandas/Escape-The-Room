﻿using System;
using System.IO;
using System.Collections.Generic;
// Names:

namespace IntroCS
{
	/// A class that maintains a list of items. 
	public class Inventory
	{
		private List<Item> InventoryList;

		/// Create an empty list of books. 
		public Inventory()
		{
			InventoryList = new List<Item>();
		}
		//AddBook chunk
		// Add book to the list.
		// The regular assignment version always returns true. 
		public bool Additem(Item item)
		{   // code
			InventoryList.Add (item);
			return true; //always true in basic assignment
		}
		//PrintList chunk
		/// List the full descriptions of each book,
		/// with each book separated by a blank line. 

		public bool CheckInventory(string title){
			foreach (Item i in InventoryList) {
				if (i.GetTitle () == title) {
					return true;
				}
			}
			return false;
		}

		public void PrintInventory() // 
		{  // everyone code;    for extra credit, note assignment instructions
			InventoryList.ForEach(Console.WriteLine);
		}

		public void ExamineItem(string title){
			foreach (Item i in InventoryList) {
				if (i.GetTitle () == title) {
					Console.WriteLine (i.GetDescription ());
				}
			}
		}

		public void AddMagic(string title){
			for (int j = 0; j < InventoryList.Count; j++) {
				if (InventoryList [j].GetTitle () == title) {
					InventoryList.RemoveAt (j);
					break;
				}
			}
		}
	}
}
